import tooltils


#logger = tooltils.info.logger()
#advContext = tooltils.requests.advancedContext(extraLogs=True)

#https:  bool = True
#verify: bool = False

#print(conn.send('POST', '/post').status_code)
#print(conn.send('HEAD', '/get').status_code)
#print(conn.send('PUT', '/put').status_code)
#print(conn.send('PATCH', '/patch').status_code)
#print(conn.send('OPTIONS', '/get').status_code)

#print(tooltils.requests.get('httpbin.org/get', https=https, verify=verify).status_code)
#print(tooltils.requests.post('httpbin.org/post', https=https, verify=verify).status_code)
#print(tooltils.requests.head('httpbin.org/get', https=https, verify=verify).status_code)
#print(tooltils.requests.put('httpbin.org/put', https=https, verify=verify).status_code)
#print(tooltils.requests.patch('httpbin.org/patch', https=https, verify=verify).status_code)
#print(tooltils.requests.options('httpbin.org/get', https=https, verify=verify).status_code)

